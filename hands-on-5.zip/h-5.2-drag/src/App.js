import React from "react";
import Draggable from "react-draggable";
import "bootstrap/dist/css/bootstrap.css";
import Card from "./Card";

function App() {
  return (
    <>
      <container style={{ display: "flex", marginBottom: "20px" }}>
        <Draggable handle="strong">
          <div
            className="card"
            style={{
              display: "flex",
              height: "200px",
              width: "18rem",
              flexDirection: "column",
              marginRight: "20px",
            }}
          >
            <strong className="cursor">
              <div>I can be dragged anywhere</div>
            </strong>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
          </div>
        </Draggable>
        <Draggable handle="strong" axis="x">
          <div
            className="card"
            style={{
              display: "flex",
              height: "200px",
              width: "18rem",
              flexDirection: "column",
            }}
          >
            <strong className="cursor">
              <div>I can only be dragged horizonally (x axis)</div>
            </strong>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
          </div>
        </Draggable>
        <br />
      </container>
      <container style={{ display: "flex" }}>
        <Draggable handle="strong">
          <div
            className="card"
            style={{
              display: "flex",
              height: "200px",
              width: "18rem",
              flexDirection: "column",
              marginRight: "20px",
            }}
          >
            <strong className="cursor">
              <div>Drag here</div>
            </strong>
            <div style={{ overflow: "scroll" }}>
              <div style={{ background: "yellow", whiteSpace: "pre-wrap" }}>
                I have long scrollable content with a handle
                {"\n" + Array(40).fill("000").join("\n")}
              </div>
            </div>
          </div>
        </Draggable>
        <card handle="strong">
          <div
            className="card"
            style={{
              display: "flex",
              height: "200px",
              width: "18rem",
              flexDirection: "column",
            }}
          >
            <strong className="cursor">
              <div>Can't Drag here</div>
            </strong>
            <div>
              <div>Dragging here Works</div>
            </div>
          </div>
        </card>
      </container>
    </>
  );
}
export default App;
