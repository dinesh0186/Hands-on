let status = true;
let table = document.getElementById("mytable");

fetch("http://localhost:3000/Employees")
  .then((response) => response.json())
  .then((arr) => {
    for (let obj of arr) {
      let row = table.insertRow();
      let cell1 = row.insertCell();
      let cell2 = row.insertCell();
      let cell3 = row.insertCell();
      cell3.id = "skil" + arr.indexOf(obj);
      let cell4 = row.insertCell();
      let cell5 = row.insertCell();
      let cell6 = row.insertCell();
      let cell7 = row.insertCell();

      cell1.innerHTML = obj.Name;
      cell2.innerHTML = obj.ID;
      cell3.innerHTML = obj.skills;
      cell3.className = "editable";
      cell4.innerHTML = obj.project;
      cell5.innerHTML = obj.Location;
      cell6.innerHTML =
        '<i class="far fa-edit" onclick="editrow(' +
        arr.indexOf(obj) +
        ')"></i>';
      cell6.id = "ed" + arr.indexOf(obj);
      cell7.innerHTML =
        '<button onclick="deleterow(' +
        arr.indexOf(obj) +
        ')" class="btn btn-danger"> X </button>';
    }

    for (let obj of arr) {
      let coll = document.createElement("div");
      coll.className = "col";
      coll.id = "crd" + arr.indexOf(obj);
      let el = document.createElement("div");
      el.className = "card shadow m-5";

      let elh = document.createElement("div");

      el.appendChild(elh);
      elh.innerHTML =
        '<i class="fas fa-times" style="color:red;float:right;font-size:18px" onclick="deletecard(' +
        arr.indexOf(obj) +
        ')"></i>';

      let el2 = document.createElement("div");
      el2.className = "card-body text-left";
      el.appendChild(el2);
      let imgg = document.createElement("img");
      imgg.src = obj.placeholder;
      imgg.style.width = "100%";
      el2.appendChild(imgg);
      let pname = document.createElement("p");
      pname.innerHTML = "Name: " + obj.Name;
      el2.appendChild(pname);
      let pid = document.createElement("p");
      pid.innerHTML = "ID: " + obj.ID;
      pname.style.marginTop = "20px";
      el2.appendChild(pid);
      let pskills = document.createElement("p");
      pskills.innerHTML = "Skills: " + obj.skills;
      pskills.id = "skilc" + arr.indexOf(obj);
      el2.appendChild(pskills);
      let pproject = document.createElement("p");
      pproject.innerHTML = "Project:" + obj.project;
      el2.appendChild(pproject);
      let plocation = document.createElement("p");
      plocation.innerHTML = "Location: " + obj.Location;
      el2.appendChild(plocation);
      let elf = document.createElement("div");
      el.appendChild(elf);
      elf.innerHTML =
        '<a href="#"  style="margin-left:200px;  " onclick="editcard(' +
        arr.indexOf(obj) +
        ')">Edit</a> <a href="#"  style="padding-bottom:5px" onclick="savecard(' +
        arr.indexOf(obj) +
        ')">/Save</i>';
      elf.style.marginBottom = "10px";
      elf.id = "but" + arr.indexOf(obj);

      coll.appendChild(el);
      let p = document.getElementById("lst");
      p.appendChild(coll);
    }
  });

myfun();

//EDITING THE ROW ELEMENTS//
function editrow(emp) {
  let x = document.getElementById("skil" + emp);
  let y = document.getElementById("ed" + emp);
  x.innerHTML = '<input type="text" id="entered' + emp + '">';
  y.innerHTML = '<i class="far fa-save" onclick=saverow(' + emp + ")></i>";
}

//SAVING THE ROW//
function saverow(emp) {
  let data = document.getElementById("entered" + emp).value;
  let x = document.getElementById("skil" + emp);
  x.innerHTML = data;
  let y = document.getElementById("ed" + emp);
  let z = document.getElementById("skils" + emp);
  z.innerHTML = "Skills: " + data;
  y.innerHTML = '<i class="far fa-edit" onclick="editcard(' + emp + ')"></i>';
}

//DELETING THE ROW//
function deleterow(emp) {
  let x = document.querySelectorAll("tr");
  x[emp + 1].style.display = "none";

  deletecard(emp);
}

//DELETING THE CARD//
function deletecard(emp) {
  let x = document.getElementById("crd" + emp);
  x.style.display = "none";
  deleterow(emp);
}

//SAVING THE CARD//
function savecard(emp) {
  let data = document.getElementById("enteredc" + emp).value;
  let z = document.getElementById("skilc" + emp);
  z.innerHTML = "Skills: " + data;
  let x = document.getElementById("skil" + emp);
  x.innerHTML = data;
}
//EDITING THE CARD//
function editcard(emp) {
  let x = document.getElementById("skilc" + emp);
  x.innerHTML =
    '<label for="enteredc' +
    emp +
    '">Skills:</label><input type="text" id="enteredc' +
    emp +
    '">';
}

function myfun(arr) {
  status = !status;
  if (!status) {
    let x = document.getElementById("lst");
    let y = document.getElementById("cnt");
    let a = document.getElementById("grid");
    let b = document.getElementById("tbview");
    x.style.display = "flex";
    y.style.display = "block";
    a.style.display = "block";
    b.style.display = "none";
  } else {
    let x = document.getElementById("lst");
    let y = document.getElementById("cnt");
    let a = document.getElementById("grid");
    let b = document.getElementById("tbview");
    x.style.display = "flex";
    y.style.display = "none";
    a.style.display = "none";
    b.style.display = "block";
  }
}
