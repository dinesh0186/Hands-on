import "./App.css";
import Tabledata from "./Tabledata";

function App() {
  return (
    <div className="App">
      <Tabledata />
    </div>
  );
}
export default App;
