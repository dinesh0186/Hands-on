const express = require("express");
const mongoose = require("mongoose");
const Employee = require("./model");
const employeeRoutes = require("./route");
const app = express();
const cors = require("cors");
const port = 7070;

const connectToDB = async function () {
  await mongoose.connect("mongodb://localhost/users");
  console.log("Connected to DB");
};

connectToDB();

app.use(cors());
app.use(express.json());

app.use("/employees", employeeRoutes);
app.get("/", async (req, res) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    console.log(page);

    const limit = parseInt(req.query.limit, 10) || 25;
    console.log(limit);
    const firstindex = (page - 1) * limit;
    const lastindex = page * limit;
    const employees = await Employee.find().skip(firstindex).limit(limit);

    res.json(employees);
  } catch (e) {
    console.log(e);
  }
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
